-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `Fire`;
CREATE TABLE `Fire` (
  `upload_time` datetime NOT NULL,
  `county` char(40) DEFAULT NULL,
  `nb_case` int DEFAULT NULL,
  `validate` int DEFAULT '0',
  PRIMARY KEY (`upload_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Fire` (`upload_time`, `county`, `nb_case`, `validate`) VALUES
('2020-11-09 23:09:22',	'test',	9,	0);

-- 2020-11-09 23:09:31
