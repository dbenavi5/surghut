-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `Alert`;
CREATE TABLE `Alert` (
  `mail` char(40) NOT NULL,
  `county` char(40) NOT NULL,
  PRIMARY KEY (`mail`,`county`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Alert` (`mail`, `county`) VALUES
('docmurloc@gmail.com',	'Alameda'),
('docmurloc@gmail.com',	'paris'),
('pierre.ant7@hotmail.com',	'Alameda');

DROP TABLE IF EXISTS `County`;
CREATE TABLE `County` (
  `id` tinyint DEFAULT NULL,
  `name` char(40) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `covide_case` mediumint DEFAULT '0',
  `covide_death` mediumint DEFAULT '0',
  `fire_case` int DEFAULT '0',
  `evacuation_level` tinyint DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `County` (`id`, `name`, `latitude`, `longitude`, `covide_case`, `covide_death`, `fire_case`, `evacuation_level`) VALUES
(1,	'Alameda',	37.6505,	-121.918,	0,	0,	10,	2),
(2,	'Alpine',	38.5973,	-119.821,	30,	20,	10,	0),
(3,	'Amador',	38.4464,	-120.651,	0,	0,	0,	0),
(4,	'Butte',	39.6669,	-121.601,	0,	0,	0,	0),
(5,	'Calaveras',	38.2046,	-120.554,	0,	0,	0,	0),
(6,	'Colusa',	39.1776,	-122.237,	0,	0,	0,	0),
(7,	'Contra Costa',	37.9234,	-121.951,	0,	0,	0,	0),
(8,	'Del Norte',	41.7449,	-123.958,	0,	0,	0,	0),
(9,	'El Dorado',	38.7787,	-120.525,	0,	0,	0,	0),
(10,	'Fresno',	36.7582,	-119.649,	0,	0,	0,	0),
(11,	'Glenn',	39.5984,	-122.392,	0,	0,	0,	0),
(12,	'Humboldt',	40.705,	-123.916,	0,	0,	0,	0),
(13,	'Imperial',	33.0396,	-115.365,	0,	0,	0,	0),
(14,	'Inyo',	36.5111,	-117.411,	0,	0,	0,	0),
(15,	'Kern',	35.3428,	-118.73,	0,	0,	0,	0),
(16,	'Kings',	36.0754,	-119.816,	0,	0,	0,	0),
(17,	'Lake',	39.0996,	-122.753,	0,	0,	0,	0),
(18,	'Lassen',	40.6736,	-120.594,	0,	0,	0,	0),
(19,	'Los Angeles',	34.198,	-118.261,	0,	0,	0,	0),
(20,	'Madera',	37.218,	-119.763,	0,	0,	0,	0),
(21,	'Marin',	38.0552,	-122.749,	0,	0,	0,	0),
(22,	'Mariposa',	37.5815,	-119.906,	0,	0,	0,	0),
(23,	'Mendocino',	39.4336,	-123.432,	0,	0,	0,	0),
(24,	'Merced',	37.1919,	-120.718,	0,	0,	0,	0),
(25,	'Modoc',	41.5898,	-120.725,	0,	0,	0,	0),
(26,	'Mono',	37.939,	-118.887,	0,	0,	0,	0),
(27,	'Monterey',	36.2398,	-121.309,	0,	0,	0,	0),
(28,	'Napa',	38.5065,	-122.331,	0,	0,	0,	0),
(29,	'Nevada',	39.3014,	-120.769,	0,	0,	0,	0),
(30,	'Orange',	33.6769,	-117.776,	0,	0,	0,	0),
(31,	'Placer',	39.0634,	-120.718,	0,	0,	0,	0),
(32,	'Plumas',	40.0047,	-120.839,	0,	0,	0,	0),
(33,	'Riverside',	33.7437,	-115.994,	0,	0,	0,	0),
(34,	'Sacramento',	38.4493,	-121.344,	0,	0,	0,	0),
(35,	'San Benito',	36.6057,	-121.075,	0,	0,	0,	0),
(36,	'San Bernardino',	34.8414,	-116.178,	0,	0,	0,	0),
(37,	'San Diego',	33.0282,	-116.77,	0,	0,	0,	0),
(38,	'San Francisco',	37.7597,	-122.694,	0,	0,	0,	0),
(39,	'San Joaquin',	37.9347,	-121.271,	0,	0,	0,	0),
(40,	'San Luis Obispo',	35.3874,	-120.452,	0,	0,	0,	0),
(41,	'San Mateo',	37.4362,	-122.356,	0,	0,	0,	0),
(42,	'Santa Barbara',	34.5383,	-120.031,	0,	0,	0,	0),
(43,	'Santa Clara',	37.2325,	-121.696,	0,	0,	0,	0),
(44,	'Santa Cruz',	37.0216,	-122.01,	0,	0,	0,	0),
(45,	'Shasta',	40.7638,	-122.041,	0,	0,	0,	0),
(46,	'Sierra',	39.5804,	-120.516,	0,	0,	0,	0),
(47,	'Siskiyou',	41.5927,	-122.54,	0,	0,	0,	0),
(48,	'Solano',	38.2669,	-121.94,	0,	0,	0,	0),
(49,	'Sonoma',	38.5253,	-122.923,	0,	0,	0,	0),
(50,	'Stanislaus',	37.5591,	-120.998,	0,	0,	0,	0),
(51,	'Sutter',	39.0346,	-121.695,	0,	0,	0,	0),
(52,	'Tehama',	40.1257,	-122.234,	0,	0,	0,	0),
(53,	'Trinity',	40.6507,	-123.113,	0,	0,	0,	0),
(54,	'Tulare',	36.2202,	-118.8,	0,	0,	0,	0),
(55,	'Tuolumne',	38.0276,	-119.955,	0,	0,	0,	0),
(56,	'Ventura',	34.3575,	-119.126,	0,	0,	0,	0),
(57,	'Yolo',	38.6867,	-121.902,	0,	0,	0,	0),
(58,	'Yuba',	39.269,	-121.351,	0,	0,	0,	0);

DROP TABLE IF EXISTS `Covid`;
CREATE TABLE `Covid` (
  `upload_time` datetime NOT NULL,
  `nb_case` int DEFAULT NULL,
  `county` char(40) DEFAULT NULL,
  `validate` int DEFAULT '0',
  `nb_death` int DEFAULT NULL,
  PRIMARY KEY (`upload_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Covid` (`upload_time`, `nb_case`, `county`, `validate`, `nb_death`) VALUES
('2020-11-09 23:07:24',	9,	'MDR',	1,	NULL),
('2020-11-10 14:59:54',	10,	'Alpine',	1,	NULL),
('2020-11-15 17:09:21',	20,	'Alpine',	1,	30),
('2020-11-15 17:12:31',	30,	'Alpine',	1,	20);

DROP TABLE IF EXISTS `Fire`;
CREATE TABLE `Fire` (
  `upload_time` datetime NOT NULL,
  `county` char(40) DEFAULT NULL,
  `nb_case` int DEFAULT NULL,
  `validate` int DEFAULT '0',
  PRIMARY KEY (`upload_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Fire` (`upload_time`, `county`, `nb_case`, `validate`) VALUES
('2020-11-09 23:09:22',	'test',	9,	1),
('2020-11-10 23:51:45',	'Alpine',	10,	1),
('2020-11-15 17:13:05',	'Alameda',	100,	1),
('2020-11-28 18:06:07',	'Alameda',	10,	1);

DROP TABLE IF EXISTS `Mailbox`;
CREATE TABLE `Mailbox` (
  `upload_time` datetime NOT NULL,
  `sender` char(40) NOT NULL,
  `receiver` char(40) NOT NULL,
  `object` char(100) DEFAULT NULL,
  `message` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`upload_time`,`sender`,`receiver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Mailbox` (`upload_time`, `sender`, `receiver`, `object`, `message`) VALUES
('2020-11-09 23:53:44',	'pierre',	'antoine',	'test mail',	'test the mail in the data base'),
('2020-11-11 00:51:41',	'pierre',	'test',	'test again',	'this is a test');

DROP TABLE IF EXISTS `Profile`;
CREATE TABLE `Profile` (
  `pseudo` char(40) DEFAULT NULL,
  `mail` char(40) DEFAULT NULL,
  `password` char(40) DEFAULT NULL,
  `access_token` char(50) DEFAULT NULL,
  `access_level` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Profile` (`pseudo`, `mail`, `password`, `access_token`, `access_level`) VALUES
('pierre',	'test@test',	'test',	'6mnuqwmcxcjzfluufri559',	2);

-- 2020-11-28 18:07:55
