-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `Covid`;
CREATE TABLE `Covid` (
  `upload_time` datetime NOT NULL,
  `nb_case` int DEFAULT NULL,
  `county` char(40) DEFAULT NULL,
  PRIMARY KEY (`upload_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Covid` (`upload_time`, `nb_case`, `county`) VALUES
('2020-11-09 13:50:59',	9,	'county');

-- 2020-11-09 13:51:58
