-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `Profile`;
CREATE TABLE `Profile` (
  `pseudo` char(40) DEFAULT NULL,
  `mail` char(40) DEFAULT NULL,
  `password` char(40) DEFAULT NULL,
  `access_token` char(50) DEFAULT NULL,
  `access_level` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Profile` (`pseudo`, `mail`, `password`, `access_token`, `access_level`) VALUES
('pierre',	'test@test',	'test',	'vsgeebi1v19ff0qrcj0wsl',	0);

-- 2020-11-09 13:00:16
